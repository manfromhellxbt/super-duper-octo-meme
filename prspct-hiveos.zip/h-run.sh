#!/usr/bin/env bash
# HiveOS custom miner: PRSPCT (Robinhood Chain 4663)
set -uo pipefail
cd "$(dirname "$0")"

chmod +x ./prspct-miner 2>/dev/null || true
export PRSPCT_KERNEL_PATH="${PRSPCT_KERNEL_PATH:-$PWD/kernel.cl}"

RPC="${PRSPCT_RPC:-https://rpc.mainnet.chain.robinhood.com}"
CONTRACT="${PRSPCT_CONTRACT:-0xd078008c3D887A52CE722A3cA0539cA1F4971dD1}"
DEVICE="${PRSPCT_DEVICE:-0}"
WORK="${PRSPCT_WORK:-262144}"
BATCH="${PRSPCT_BATCH:-256}"
POLL="${PRSPCT_POLL:-8}"

# optional env file (written via HiveOS → Worker → Commands)
if [[ -f ./config.env ]]; then
  # shellcheck disable=SC1091
  source ./config.env
fi

ARGS=(--rpc "$RPC" --contract "$CONTRACT" --device "$DEVICE" --work "$WORK" --batch "$BATCH" --poll "$POLL")

if [[ -f ./pk.txt ]]; then
  ARGS+=(--pk-file ./pk.txt)
elif [[ -n "${PRSPCT_PK:-}" ]]; then
  ARGS+=(--pk "$PRSPCT_PK")
elif [[ -n "${PRSPCT_SENDER:-}" ]]; then
  ARGS+=(--sender "$PRSPCT_SENDER")
else
  echo "prspct: no key. Run in HiveOS Commands:"
  echo "  echo '0xYOUR_KEY' > /hive/miners/custom/prspct/pk.txt && chmod 600 /hive/miners/custom/prspct/pk.txt"
  exit 1
fi

# HiveOS may pass extra args from flight sheet
# shellcheck disable=SC2086
exec ./prspct-miner "${ARGS[@]}" ${CUSTOM_USER_CONFIG:-}
