#!/usr/bin/env bash
# HiveOS stats: scrape hashrate from miner log
set -euo pipefail
cd "$(dirname "$0")"

LOG="${1:-/var/log/miner/prspct.log}"
# fallback: hive default
if [[ ! -f "$LOG" ]]; then
  LOG=$(ls -t /tmp/prspct*.log /var/log/miner/*prspct* 2>/dev/null | head -1 || true)
fi

HS=0
if [[ -n "${LOG:-}" && -f "$LOG" ]]; then
  # last "status: X.XX MH/s"
  line=$(grep -oE 'status: [0-9.]+ MH/s' "$LOG" 2>/dev/null | tail -1 || true)
  if [[ -n "$line" ]]; then
    HS=$(echo "$line" | awk '{print $2}')
  fi
fi

# Hive expects JSON with hs (array or number), hs_units, temp, fan, uptime
echo "{\"hs\":[$HS],\"hs_units\":\"mhs\",\"temp\":[0],\"fan\":[0],\"uptime\":0}"
