#ifndef PRSPCT_UTIL_H
#define PRSPCT_UTIL_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* ---- hex ---- */
int hex2bin(const char *hex, uint8_t *out, size_t outlen);
void bin2hex(const uint8_t *in, size_t inlen, char *out); /* out needs 2*inlen+1 */
int parse_u64_hex(const char *s, uint64_t *out);

/* ---- tiny dynamic buffer ---- */
typedef struct {
    uint8_t *data;
    size_t len, cap;
} buf_t;

void buf_init(buf_t *b);
void buf_free(buf_t *b);
int  buf_push(buf_t *b, const void *p, size_t n);
int  buf_push_u8(buf_t *b, uint8_t v);

/* ---- JSON helpers (flat object, good enough for eth_call hex strings) ---- */
/* Find "key":"value" string value inside json; copies into out (NUL-term). */
bool json_get_string(const char *json, const char *key, char *out, size_t outlen);
/* Find "key":number */
bool json_get_u64(const char *json, const char *key, uint64_t *out);

/* ---- RLP ---- */
/* Encode a single byte string; if len==1 && byte<0x80, the string is its own encoding. */
int rlp_bytes(buf_t *out, const uint8_t *data, size_t len);
/* Encode list whose items are already RLP-encoded and concatenated in `items`. */
int rlp_list(buf_t *out, const uint8_t *items, size_t items_len);
/* Encode uint64 as minimal big-endian byte string then RLP. */
int rlp_u64(buf_t *out, uint64_t v);

#endif
