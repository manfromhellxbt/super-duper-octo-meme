#include "rpc.h"
#include <curl/curl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void rpc_init(rpc_t *r, const char *url) {
    snprintf(r->url, sizeof(r->url), "%s", url);
    curl_global_init(CURL_GLOBAL_DEFAULT);
}

static size_t write_cb(char *ptr, size_t size, size_t nmemb, void *userdata) {
    buf_t *b = userdata;
    size_t n = size * nmemb;
    if (buf_push(b, ptr, n)) return 0;
    return n;
}

int rpc_call_raw(rpc_t *r, const char *body, buf_t *out) {
    buf_init(out);
    CURL *c = curl_easy_init();
    if (!c) return -1;
    struct curl_slist *hdrs = NULL;
    hdrs = curl_slist_append(hdrs, "Content-Type: application/json");
    curl_easy_setopt(c, CURLOPT_URL, r->url);
    curl_easy_setopt(c, CURLOPT_HTTPHEADER, hdrs);
    curl_easy_setopt(c, CURLOPT_POSTFIELDS, body);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, out);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 20L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(c);
    long http = 0;
    curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &http);
    curl_slist_free_all(hdrs);
    curl_easy_cleanup(c);
    if (rc != CURLE_OK) return -1;
    if (http < 200 || http >= 300) return -1;
    if (buf_push_u8(out, 0)) return -1; /* NUL */
    return 0;
}

static int rpc_json(rpc_t *r, const char *method, const char *params, char *result, size_t result_cap) {
    char body[2048];
    snprintf(body, sizeof(body),
             "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"%s\",\"params\":%s}",
             method, params);
    buf_t resp;
    if (rpc_call_raw(r, body, &resp)) { buf_free(&resp); return -1; }
    /* extract "result":"..." or "result":{...} / number — we only need hex strings and numbers */
    const char *p = strstr((char *)resp.data, "\"result\"");
    if (!p) { buf_free(&resp); return -1; }
    p += 8;
    while (*p == ' ' || *p == ':') p++;
    if (*p == '"') {
        p++;
        size_t i = 0;
        while (*p && *p != '"' && i + 1 < result_cap) result[i++] = *p++;
        result[i] = 0;
    } else {
        size_t i = 0;
        while (*p && *p != ',' && *p != '}' && i + 1 < result_cap) result[i++] = *p++;
        result[i] = 0;
    }
    buf_free(&resp);
    return 0;
}

int rpc_eth_call(rpc_t *r, const char *to, const char *data, char *result_hex, size_t result_cap) {
    char params[512];
    snprintf(params, sizeof(params),
             "[{\"to\":\"%s\",\"data\":\"%s\"},\"latest\"]", to, data);
    return rpc_json(r, "eth_call", params, result_hex, result_cap);
}

int rpc_chain_id(rpc_t *r, uint64_t *chain_id) {
    char res[64];
    if (rpc_json(r, "eth_chainId", "[]", res, sizeof(res))) return -1;
    return parse_u64_hex(res, chain_id);
}

int rpc_gas_price(rpc_t *r, uint64_t *price) {
    char res[64];
    if (rpc_json(r, "eth_gasPrice", "[]", res, sizeof(res))) return -1;
    return parse_u64_hex(res, price);
}

int rpc_get_nonce(rpc_t *r, const char *addr, uint64_t *nonce) {
    char params[128], res[64];
    snprintf(params, sizeof(params), "[\"%s\",\"pending\"]", addr);
    if (rpc_json(r, "eth_getTransactionCount", params, res, sizeof(res))) return -1;
    return parse_u64_hex(res, nonce);
}

int rpc_send_raw(rpc_t *r, const char *raw0x, char *tx_hash_hex, size_t cap) {
    char params[4096];
    snprintf(params, sizeof(params), "[\"%s\"]", raw0x);
    return rpc_json(r, "eth_sendRawTransaction", params, tx_hash_hex, cap);
}

int rpc_block_number(rpc_t *r, uint64_t *n) {
    char res[64];
    if (rpc_json(r, "eth_blockNumber", "[]", res, sizeof(res))) return -1;
    return parse_u64_hex(res, n);
}

/* state() selector 0xc19d93fb
 * ABI: (uint256 depth, bytes32 seed, uint256 openAt, uint256 price, uint256 target, ...)
 */
int prspct_fetch_state(rpc_t *r, const char *contract, prspct_state_t *st) {
    char res[2048];
    if (rpc_eth_call(r, contract, "0xc19d93fb", res, sizeof(res))) return -1;
    const char *hex = res;
    if (hex[0] == '0' && (hex[1] == 'x' || hex[1] == 'X')) hex += 2;
    /* word0 depth, word1 seed, word4 target */
    size_t need = 5 * 64;
    if (strlen(hex) < need) return -1;
    char w[65];
    memcpy(w, hex, 64); w[64] = 0;
    uint64_t depth = 0;
    parse_u64_hex(w, &depth);
    st->depth = depth;
    memcpy(w, hex + 64, 64); w[64] = 0;
    if (hex2bin(w, st->seed, 32) != 32) return -1;
    memcpy(w, hex + 4 * 64, 64); w[64] = 0;
    if (hex2bin(w, st->target, 32) != 32) return -1;
    return 0;
}
