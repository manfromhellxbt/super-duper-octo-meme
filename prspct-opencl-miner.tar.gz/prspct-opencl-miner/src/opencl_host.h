#ifndef PRSPCT_OPENCL_HOST_H
#define PRSPCT_OPENCL_HOST_H

#include <stdint.h>
#include <stddef.h>

typedef struct ocl_ctx ocl_ctx_t;

/* Create context on platform/device. device_index selects among GPU devices (0-based).
 * kernel_src_path: path to kernel.cl (or NULL to use PRSPCT_KERNEL_PATH / next to exe). */
ocl_ctx_t *ocl_create(int device_index, const char *kernel_src_path);
void ocl_destroy(ocl_ctx_t *c);

/* Launch a search. Returns 0 on ok.
 * found_nonce valid only if *found == 1.
 * hashes_per_item: inner loop count per work-item (1..N).
 * global_size: number of work-items (rounded up to local_size multiple if needed). */
int ocl_search(ocl_ctx_t *c,
               const uint64_t base_lanes[17],
               const uint8_t target[32],
               uint64_t start_nonce,
               uint64_t global_size,
               uint64_t hashes_per_item,
               int *found, uint64_t *found_nonce, uint64_t *total_hashes);

const char *ocl_device_name(ocl_ctx_t *c);

#endif
