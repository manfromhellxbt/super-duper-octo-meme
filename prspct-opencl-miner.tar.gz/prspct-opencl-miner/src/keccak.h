#ifndef PRSPCT_KECCAK_H
#define PRSPCT_KECCAK_H

#include <stdint.h>
#include <stddef.h>

/* Ethereum Keccak-256 (pre-NIST padding: 0x01 domain). */
void keccak256(const uint8_t *in, size_t inlen, uint8_t out[32]);

/* Build the 17-lane absorb state for seed||sender||0-nonce (pad applied).
 * nonce lanes (9,10) are left zero; the kernel patches them. */
void prspct_base_state(const uint8_t seed[32], const uint8_t sender[20],
                       uint64_t lanes[17]);

/* CPU reference: keccak256(seed||sender||nonce_be64_as_uint256) */
void prspct_claim_hash(const uint8_t seed[32], const uint8_t sender[20],
                       uint64_t nonce, uint8_t out[32]);

#endif
