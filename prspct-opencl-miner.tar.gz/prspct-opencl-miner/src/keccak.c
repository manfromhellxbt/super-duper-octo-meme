#include "keccak.h"
#include "sha3.h"
#include <string.h>

void keccak256(const uint8_t *in, size_t inlen, uint8_t out[32]) {
    sha3(in, inlen, out, 32);
}

void prspct_base_state(const uint8_t seed[32], const uint8_t sender[20],
                       uint64_t lanes[17]) {
    uint8_t block[136];
    memset(block, 0, sizeof(block));
    memcpy(block, seed, 32);
    memcpy(block + 32, sender, 20);
    block[84] = 0x01;
    block[135] = 0x80;
    memset(lanes, 0, 17 * sizeof(uint64_t));
    memcpy(lanes, block, 136);
}

void prspct_claim_hash(const uint8_t seed[32], const uint8_t sender[20],
                       uint64_t nonce, uint8_t out[32]) {
    uint8_t msg[84];
    memcpy(msg, seed, 32);
    memcpy(msg + 32, sender, 20);
    memset(msg + 52, 0, 24);
    for (int i = 0; i < 8; i++)
        msg[52 + 24 + i] = (uint8_t)(nonce >> (56 - 8 * i));
    keccak256(msg, 84, out);
}
