#include "keccak.h"
#include "sha3.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

static uint32_t bswap32(uint32_t x) {
    return (x << 24) | ((x & 0x0000ff00u) << 8) | ((x & 0x00ff0000u) >> 8) | (x >> 24);
}

static void to_hex(const uint8_t *in, size_t n, char *out) {
    static const char *H = "0123456789abcdef";
    for (size_t i = 0; i < n; i++) {
        out[2 * i] = H[in[i] >> 4];
        out[2 * i + 1] = H[in[i] & 0xf];
    }
    out[2 * n] = 0;
}

static int check(const char *label, const uint8_t *got, const char *want) {
    char hex[65];
    to_hex(got, 32, hex);
    int ok = strcmp(hex, want) == 0;
    printf("%s: %s\n  got  %s\n  want %s\n", label, ok ? "OK" : "FAIL", hex, want);
    return ok ? 0 : 1;
}

int main(void) {
    int fail = 0;
    uint8_t h[32];
    char hex[65];

    keccak256((const uint8_t *)"", 0, h);
    fail |= check("empty", h,
        "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");

    keccak256((const uint8_t *)"abc", 3, h);
    fail |= check("abc", h,
        "4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45");

    keccak256((const uint8_t *)"claim(uint256)", 14, h);
    to_hex(h, 4, hex);
    printf("claim selector: 0x%s (want 379607f5) %s\n", hex,
           strcmp(hex, "379607f5") ? "FAIL" : "OK");
    if (strcmp(hex, "379607f5")) fail = 1;

    keccak256((const uint8_t *)"state()", 7, h);
    to_hex(h, 4, hex);
    printf("state selector: 0x%s (want c19d93fb) %s\n", hex,
           strcmp(hex, "c19d93fb") ? "FAIL" : "OK");
    if (strcmp(hex, "c19d93fb")) fail = 1;

    uint8_t seed[32] = {0}, sender[20] = {0}, out[32];
    prspct_claim_hash(seed, sender, 0, out);
    to_hex(out, 32, hex);
    printf("zero-input claim hash: %s\n", hex);

    /* Kernel lane encoding vs CPU claim hash for several nonces */
    for (uint64_t n = 0; n < 8; n++) {
        prspct_claim_hash(seed, sender, n, out);
        uint64_t lanes[17];
        prspct_base_state(seed, sender, lanes);
        uint64_t s[25] = {0};
        memcpy(s, lanes, 17 * sizeof(uint64_t));
        s[9]  = ((uint64_t)bswap32((uint32_t)(n >> 32)) << 32);
        s[10] = (uint64_t)bswap32((uint32_t)n) | ((uint64_t)1 << 32);
        sha3_keccakf(s);
        uint8_t dig[32];
        for (int l = 0; l < 4; l++) {
            uint64_t lane = s[l];
            for (int b = 0; b < 8; b++) dig[8 * l + b] = (uint8_t)(lane >> (8 * b));
        }
        char a[65], b[65];
        to_hex(out, 32, a);
        to_hex(dig, 32, b);
        if (strcmp(a, b) != 0) {
            printf("lane/nonce=%llu FAIL\n  cpu %s\n  lanes %s\n",
                   (unsigned long long)n, a, b);
            fail = 1;
        } else {
            printf("lane/nonce=%llu OK %s\n", (unsigned long long)n, a);
        }
    }

    printf(fail ? "FAILURES\n" : "ALL OK\n");
    return fail;
}
