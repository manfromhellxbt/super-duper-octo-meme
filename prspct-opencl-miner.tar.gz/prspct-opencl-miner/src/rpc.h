#ifndef PRSPCT_RPC_H
#define PRSPCT_RPC_H

#include <stdint.h>
#include <stdbool.h>
#include "util.h"

typedef struct {
    char url[512];
} rpc_t;

void rpc_init(rpc_t *r, const char *url);

/* POST JSON body, write response into *out (caller buf_free). Returns 0 on HTTP ok. */
int rpc_call_raw(rpc_t *r, const char *body, buf_t *out);

/* eth_call. data is 0x-hex calldata. Result hex written to result_hex (NUL-term). */
int rpc_eth_call(rpc_t *r, const char *to, const char *data, char *result_hex, size_t result_cap);

int rpc_chain_id(rpc_t *r, uint64_t *chain_id);
int rpc_gas_price(rpc_t *r, uint64_t *price);
int rpc_get_nonce(rpc_t *r, const char *addr, uint64_t *nonce);
int rpc_send_raw(rpc_t *r, const char *raw0x, char *tx_hash_hex, size_t cap);
int rpc_block_number(rpc_t *r, uint64_t *n);

/* Prspct.state() -> depth, seed[32], target[32] */
typedef struct {
    uint64_t depth;
    uint8_t  seed[32];
    uint8_t  target[32]; /* full-sweat target of the next foot */
} prspct_state_t;

int prspct_fetch_state(rpc_t *r, const char *contract, prspct_state_t *st);

#endif
