#include "util.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

static int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

int hex2bin(const char *hex, uint8_t *out, size_t outlen) {
    if (hex[0] == '0' && (hex[1] == 'x' || hex[1] == 'X')) hex += 2;
    size_t n = strlen(hex);
    if (n % 2) return -1;
    if (n / 2 > outlen) return -1;
    for (size_t i = 0; i < n / 2; i++) {
        int a = hexval(hex[2 * i]), b = hexval(hex[2 * i + 1]);
        if (a < 0 || b < 0) return -1;
        out[i] = (uint8_t)((a << 4) | b);
    }
    return (int)(n / 2);
}

void bin2hex(const uint8_t *in, size_t inlen, char *out) {
    static const char *H = "0123456789abcdef";
    for (size_t i = 0; i < inlen; i++) {
        out[2 * i] = H[in[i] >> 4];
        out[2 * i + 1] = H[in[i] & 0xf];
    }
    out[2 * inlen] = 0;
}

int parse_u64_hex(const char *s, uint64_t *out) {
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    if (!*s) return -1;
    uint64_t v = 0;
    for (; *s; s++) {
        int d = hexval(*s);
        if (d < 0) return -1;
        v = (v << 4) | (uint64_t)d;
    }
    *out = v;
    return 0;
}

void buf_init(buf_t *b) { b->data = NULL; b->len = b->cap = 0; }
void buf_free(buf_t *b) { free(b->data); b->data = NULL; b->len = b->cap = 0; }

int buf_push(buf_t *b, const void *p, size_t n) {
    if (b->len + n > b->cap) {
        size_t nc = b->cap ? b->cap * 2 : 256;
        while (nc < b->len + n) nc *= 2;
        uint8_t *nd = realloc(b->data, nc);
        if (!nd) return -1;
        b->data = nd;
        b->cap = nc;
    }
    memcpy(b->data + b->len, p, n);
    b->len += n;
    return 0;
}

int buf_push_u8(buf_t *b, uint8_t v) { return buf_push(b, &v, 1); }

static const char *find_key(const char *json, const char *key) {
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return NULL;
    p += strlen(pat);
    while (*p && (*p == ' ' || *p == ':' || *p == '\t')) p++;
    return p;
}

bool json_get_string(const char *json, const char *key, char *out, size_t outlen) {
    const char *p = find_key(json, key);
    if (!p || *p != '"') return false;
    p++;
    size_t i = 0;
    while (*p && *p != '"' && i + 1 < outlen) {
        if (*p == '\\' && p[1]) { p++; }
        out[i++] = *p++;
    }
    out[i] = 0;
    return i > 0;
}

bool json_get_u64(const char *json, const char *key, uint64_t *out) {
    const char *p = find_key(json, key);
    if (!p) return false;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))
        return parse_u64_hex(p, out) == 0;
    if (!isdigit((unsigned char)*p)) return false;
    uint64_t v = 0;
    while (isdigit((unsigned char)*p)) v = v * 10 + (uint64_t)(*p++ - '0');
    *out = v;
    return true;
}

static int rlp_len_prefix(buf_t *out, uint8_t base, size_t len) {
    if (len <= 55) return buf_push_u8(out, (uint8_t)(base + len));
    uint8_t tmp[8];
    int n = 0;
    size_t v = len;
    while (v) { tmp[n++] = (uint8_t)(v & 0xff); v >>= 8; }
    if (buf_push_u8(out, (uint8_t)(base + 55 + n))) return -1;
    for (int i = n - 1; i >= 0; i--)
        if (buf_push_u8(out, tmp[i])) return -1;
    return 0;
}

int rlp_bytes(buf_t *out, const uint8_t *data, size_t len) {
    if (len == 1 && data[0] < 0x80) return buf_push_u8(out, data[0]);
    if (rlp_len_prefix(out, 0x80, len)) return -1;
    return buf_push(out, data, len);
}

int rlp_list(buf_t *out, const uint8_t *items, size_t items_len) {
    if (rlp_len_prefix(out, 0xc0, items_len)) return -1;
    return buf_push(out, items, items_len);
}

int rlp_u64(buf_t *out, uint64_t v) {
    if (v == 0) return rlp_bytes(out, (const uint8_t *)"", 0);
    uint8_t be[8];
    int n = 0;
    for (int i = 7; i >= 0; i--) {
        if (!n && ((v >> (8 * i)) & 0xff) == 0) continue;
        be[n++] = (uint8_t)((v >> (8 * i)) & 0xff);
    }
    return rlp_bytes(out, be, (size_t)n);
}
