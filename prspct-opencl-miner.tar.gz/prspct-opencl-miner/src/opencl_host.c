#include "opencl_host.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

struct ocl_ctx {
    cl_context ctx;
    cl_device_id dev;
    cl_command_queue q;
    cl_program prog;
    cl_kernel kern;
    char name[256];
    /* persistent buffers */
    cl_mem base_state;
    cl_mem target;
    cl_mem found_flag;
    cl_mem found_nonce;
    cl_mem hash_count;
    size_t hash_slots;
};

static char *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0) { fclose(f); return NULL; }
    char *buf = malloc((size_t)n + 1);
    if (!buf) { fclose(f); return NULL; }
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); return NULL; }
    buf[n] = 0;
    fclose(f);
    if (len) *len = (size_t)n;
    return buf;
}

static char *load_kernel(const char *path, size_t *len) {
    const char *cands[4];
    char beside[1024];
    cands[0] = path;
    cands[1] = getenv("PRSPCT_KERNEL_PATH");
    /* beside the binary is handled by caller passing path; also try cwd and src/ */
    cands[2] = "kernel.cl";
    cands[3] = "src/kernel.cl";
    (void)beside;
    for (int i = 0; i < 4; i++) {
        if (!cands[i] || !cands[i][0]) continue;
        char *s = read_file(cands[i], len);
        if (s) return s;
    }
    return NULL;
}

ocl_ctx_t *ocl_create(int device_index, const char *kernel_src_path) {
    cl_int err;
    cl_uint nplat = 0;
    err = clGetPlatformIDs(0, NULL, &nplat);
    if (err != CL_SUCCESS || nplat == 0) {
        fprintf(stderr, "no OpenCL platforms\n");
        return NULL;
    }
    cl_platform_id *plats = calloc(nplat, sizeof(*plats));
    clGetPlatformIDs(nplat, plats, NULL);

    cl_device_id *gpus = NULL;
    cl_uint ngpu = 0;
    for (cl_uint p = 0; p < nplat; p++) {
        cl_uint n = 0;
        if (clGetDeviceIDs(plats[p], CL_DEVICE_TYPE_GPU, 0, NULL, &n) != CL_SUCCESS || n == 0)
            continue;
        cl_device_id *tmp = realloc(gpus, (ngpu + n) * sizeof(*tmp));
        if (!tmp) break;
        gpus = tmp;
        clGetDeviceIDs(plats[p], CL_DEVICE_TYPE_GPU, n, gpus + ngpu, NULL);
        ngpu += n;
    }
    free(plats);
    if (ngpu == 0) {
        fprintf(stderr, "no OpenCL GPU devices\n");
        free(gpus);
        return NULL;
    }
    if (device_index < 0 || (cl_uint)device_index >= ngpu) {
        fprintf(stderr, "device_index %d out of range (0..%u)\n", device_index, ngpu - 1);
        free(gpus);
        return NULL;
    }

    ocl_ctx_t *c = calloc(1, sizeof(*c));
    c->dev = gpus[device_index];
    free(gpus);

    clGetDeviceInfo(c->dev, CL_DEVICE_NAME, sizeof(c->name), c->name, NULL);
    fprintf(stderr, "OpenCL device: %s\n", c->name);

    c->ctx = clCreateContext(NULL, 1, &c->dev, NULL, NULL, &err);
    if (err != CL_SUCCESS) { free(c); return NULL; }
    c->q = clCreateCommandQueue(c->ctx, c->dev, 0, &err);
    if (err != CL_SUCCESS) { clReleaseContext(c->ctx); free(c); return NULL; }

    size_t klen = 0;
    char *ksrc = load_kernel(kernel_src_path, &klen);
    if (!ksrc) {
        fprintf(stderr, "cannot read kernel.cl (set PRSPCT_KERNEL_PATH)\n");
        clReleaseCommandQueue(c->q); clReleaseContext(c->ctx); free(c);
        return NULL;
    }
    const char *src = ksrc;
    c->prog = clCreateProgramWithSource(c->ctx, 1, &src, &klen, &err);
    free(ksrc);
    if (err != CL_SUCCESS) { ocl_destroy(c); return NULL; }

    err = clBuildProgram(c->prog, 1, &c->dev, "-cl-fast-relaxed-math", NULL, NULL);
    if (err != CL_SUCCESS) {
        size_t logsz = 0;
        clGetProgramBuildInfo(c->prog, c->dev, CL_PROGRAM_BUILD_LOG, 0, NULL, &logsz);
        char *log = malloc(logsz + 1);
        if (log) {
            clGetProgramBuildInfo(c->prog, c->dev, CL_PROGRAM_BUILD_LOG, logsz, log, NULL);
            log[logsz] = 0;
            fprintf(stderr, "kernel build log:\n%s\n", log);
            free(log);
        }
        ocl_destroy(c);
        return NULL;
    }

    c->kern = clCreateKernel(c->prog, "prspct_search", &err);
    if (err != CL_SUCCESS) { ocl_destroy(c); return NULL; }

    c->base_state = clCreateBuffer(c->ctx, CL_MEM_READ_ONLY, 17 * sizeof(cl_ulong), NULL, &err);
    c->target     = clCreateBuffer(c->ctx, CL_MEM_READ_ONLY, 32, NULL, &err);
    c->found_flag = clCreateBuffer(c->ctx, CL_MEM_READ_WRITE, sizeof(cl_int), NULL, &err);
    c->found_nonce= clCreateBuffer(c->ctx, CL_MEM_WRITE_ONLY, sizeof(cl_ulong), NULL, &err);
    c->hash_slots = 1 << 20; /* 1M counters */
    c->hash_count = clCreateBuffer(c->ctx, CL_MEM_WRITE_ONLY,
                                   c->hash_slots * sizeof(cl_ulong), NULL, &err);
    if (!c->base_state || !c->target || !c->found_flag || !c->found_nonce || !c->hash_count) {
        ocl_destroy(c);
        return NULL;
    }
    return c;
}

void ocl_destroy(ocl_ctx_t *c) {
    if (!c) return;
    if (c->kern) clReleaseKernel(c->kern);
    if (c->prog) clReleaseProgram(c->prog);
    if (c->base_state) clReleaseMemObject(c->base_state);
    if (c->target) clReleaseMemObject(c->target);
    if (c->found_flag) clReleaseMemObject(c->found_flag);
    if (c->found_nonce) clReleaseMemObject(c->found_nonce);
    if (c->hash_count) clReleaseMemObject(c->hash_count);
    if (c->q) clReleaseCommandQueue(c->q);
    if (c->ctx) clReleaseContext(c->ctx);
    free(c);
}

const char *ocl_device_name(ocl_ctx_t *c) { return c ? c->name : ""; }

int ocl_search(ocl_ctx_t *c,
               const uint64_t base_lanes[17],
               const uint8_t target[32],
               uint64_t start_nonce,
               uint64_t global_size,
               uint64_t hashes_per_item,
               int *found, uint64_t *found_nonce, uint64_t *total_hashes) {
    cl_int err;
    if (global_size > c->hash_slots) global_size = c->hash_slots;

    cl_int zero = 0;
    cl_ulong znonce = 0;
    err  = clEnqueueWriteBuffer(c->q, c->base_state, CL_TRUE, 0, 17 * sizeof(cl_ulong), base_lanes, 0, NULL, NULL);
    err |= clEnqueueWriteBuffer(c->q, c->target, CL_TRUE, 0, 32, target, 0, NULL, NULL);
    err |= clEnqueueWriteBuffer(c->q, c->found_flag, CL_TRUE, 0, sizeof(cl_int), &zero, 0, NULL, NULL);
    err |= clEnqueueWriteBuffer(c->q, c->found_nonce, CL_TRUE, 0, sizeof(cl_ulong), &znonce, 0, NULL, NULL);
    if (err != CL_SUCCESS) return -1;

    cl_ulong stride = 1; /* contiguous nonces; start re-randomized by caller */
    err  = clSetKernelArg(c->kern, 0, sizeof(cl_mem), &c->base_state);
    err |= clSetKernelArg(c->kern, 1, sizeof(cl_mem), &c->target);
    err |= clSetKernelArg(c->kern, 2, sizeof(cl_ulong), &start_nonce);
    err |= clSetKernelArg(c->kern, 3, sizeof(cl_ulong), &stride);
    err |= clSetKernelArg(c->kern, 4, sizeof(cl_ulong), &hashes_per_item);
    err |= clSetKernelArg(c->kern, 5, sizeof(cl_mem), &c->found_flag);
    err |= clSetKernelArg(c->kern, 6, sizeof(cl_mem), &c->found_nonce);
    err |= clSetKernelArg(c->kern, 7, sizeof(cl_mem), &c->hash_count);
    if (err != CL_SUCCESS) return -1;

    size_t global = (size_t)global_size;
    size_t local = 64;
    /* pick a local size that divides */
    while (local > 1 && (global % local)) local /= 2;
    if (local < 1) local = 1;

    err = clEnqueueNDRangeKernel(c->q, c->kern, 1, NULL, &global, &local, 0, NULL, NULL);
    if (err != CL_SUCCESS) return -1;
    clFinish(c->q);

    cl_int f = 0;
    cl_ulong fn = 0;
    clEnqueueReadBuffer(c->q, c->found_flag, CL_TRUE, 0, sizeof(cl_int), &f, 0, NULL, NULL);
    clEnqueueReadBuffer(c->q, c->found_nonce, CL_TRUE, 0, sizeof(cl_ulong), &fn, 0, NULL, NULL);

    /* sum hash counters (sampled; full sum if global small enough) */
    uint64_t total = 0;
    if (global <= 4096) {
        cl_ulong *tmp = malloc(global * sizeof(cl_ulong));
        if (tmp) {
            clEnqueueReadBuffer(c->q, c->hash_count, CL_TRUE, 0, global * sizeof(cl_ulong), tmp, 0, NULL, NULL);
            for (size_t i = 0; i < global; i++) total += tmp[i];
            free(tmp);
        }
    } else {
        /* estimate: each item hashes hashes_per_item unless found early */
        total = global * hashes_per_item;
        if (f) total /= 2; /* rough */
    }

    *found = f ? 1 : 0;
    *found_nonce = fn;
    *total_hashes = total;
    return 0;
}
