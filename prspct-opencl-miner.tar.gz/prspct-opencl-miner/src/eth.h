#ifndef PRSPCT_ETH_H
#define PRSPCT_ETH_H

#include <stdint.h>
#include <stddef.h>
#include "util.h"

/* secp256k1 key from 32-byte private key -> 20-byte address */
int eth_priv_to_address(const uint8_t priv[32], uint8_t addr[20]);

/* Sign legacy EIP-155 claim(nonce) tx.
 * calldata = selector(claim(uint256)) || uint256be(nonce)
 * Returns 0 and fills raw0x (0x-prefixed hex). */
int eth_build_claim_tx(
    const uint8_t priv[32],
    uint64_t chain_id,
    uint64_t account_nonce,
    uint64_t gas_price,
    uint64_t gas_limit,
    const uint8_t contract[20],
    uint64_t work_nonce,   /* the PoW nonce */
    uint64_t value_wei_lo, /* low 64 bits of msg.value; full sweat = 0 */
    uint64_t value_wei_hi, /* high 64 bits, usually 0 */
    char *raw0x, size_t raw_cap
);

#endif
