/* prspct-miner — OpenCL miner for PRSPCT on Robinhood Chain (4663)
 *
 * Hash: keccak256(seed || sender || nonce_u256be) < target
 * Claim: claim(nonce) payable  (value 0 for pure sweat)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <inttypes.h>

#include "keccak.h"
#include "rpc.h"
#include "eth.h"
#include "opencl_host.h"

#define DEFAULT_RPC     "https://rpc.mainnet.chain.robinhood.com"
#define DEFAULT_CONTRACT "0xd078008c3D887A52CE722A3cA0539cA1F4971dD1"
#define DEFAULT_CHAIN   4663ULL
#define DEFAULT_GAS     300000ULL

static volatile int g_stop = 0;
static void on_sig(int s) { (void)s; g_stop = 1; }

static uint64_t now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}

static uint64_t rand64(void) {
    static int init = 0;
    if (!init) { srand((unsigned)(time(NULL) ^ getpid())); init = 1; }
    return ((uint64_t)rand() << 33) ^ ((uint64_t)rand() << 12) ^ (uint64_t)rand() ^
           ((uint64_t)time(NULL) << 20);
}

static void usage(const char *argv0) {
    fprintf(stderr,
        "Usage: %s [options]\n"
        "  --rpc URL              RPC endpoint (default %s)\n"
        "  --contract 0x...       Prspct address (default %s)\n"
        "  --sender 0x...         Your address (required)\n"
        "  --pk 0x...             Private key (omit to mine-only, no claim)\n"
        "  --pk-file PATH         Read private key hex from file\n"
        "  --device N             OpenCL GPU index (default 0)\n"
        "  --kernel PATH          kernel.cl path\n"
        "  --work N               work-items per launch (default 262144)\n"
        "  --batch N              hashes per work-item (default 256)\n"
        "  --poll N               seconds between state refresh (default 8)\n"
        "  --list-devices         list OpenCL GPUs and exit\n"
        "  --cpu-test             verify keccak self-test and exit\n"
        "  --dry-run              fetch state, print job, do not launch GPU\n"
        "\n"
        "HiveOS: put private key in /hive/miners/custom/prspct/pk.txt (chmod 600)\n",
        argv0, DEFAULT_RPC, DEFAULT_CONTRACT);
}

static int parse_addr(const char *s, uint8_t out[20]) {
    if (hex2bin(s, out, 20) != 20) return -1;
    return 0;
}

static int parse_priv(const char *s, uint8_t out[32]) {
    if (s[0]=='0' && (s[1]=='x'||s[1]=='X')) s += 2;
    if (hex2bin(s, out, 32) != 32) return -1;
    return 0;
}

static int load_pk_file(const char *path, uint8_t out[32]) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    char buf[256] = {0};
    if (!fgets(buf, sizeof(buf), f)) { fclose(f); return -1; }
    fclose(f);
    /* strip */
    char *p = buf;
    while (*p == ' ' || *p == '\t') p++;
    size_t n = strlen(p);
    while (n && (p[n-1]=='\n' || p[n-1]=='\r' || p[n-1]==' ')) p[--n]=0;
    return parse_priv(p, out);
}

static void print_hex32(const char *label, const uint8_t *b, int n) {
    char h[129];
    bin2hex(b, (size_t)n, h);
    printf("%s0x%s", label, h);
}

static int list_devices(void) {
    /* probe platforms/devices without building a kernel */
    ocl_ctx_t *c = ocl_create(0, getenv("PRSPCT_KERNEL_PATH"));
    if (!c) {
        fprintf(stderr, "No usable OpenCL GPU (or kernel.cl missing).\n");
        fprintf(stderr, "Set PRSPCT_KERNEL_PATH or run from the miner directory.\n");
        return 1;
    }
    printf("device 0: %s\n", ocl_device_name(c));
    ocl_destroy(c);
    return 0;
}

int main(int argc, char **argv) {
    const char *rpc_url = DEFAULT_RPC;
    const char *contract = DEFAULT_CONTRACT;
    const char *sender_hex = NULL;
    const char *pk_hex = NULL;
    const char *pk_file = NULL;
    const char *kernel_path = NULL;
    int device = 0;
    uint64_t work = 262144;
    uint64_t batch = 256;
    int poll_s = 8;
    int dry = 0;

    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--rpc") && i+1 < argc) rpc_url = argv[++i];
        else if (!strcmp(argv[i], "--contract") && i+1 < argc) contract = argv[++i];
        else if (!strcmp(argv[i], "--sender") && i+1 < argc) sender_hex = argv[++i];
        else if (!strcmp(argv[i], "--pk") && i+1 < argc) pk_hex = argv[++i];
        else if (!strcmp(argv[i], "--pk-file") && i+1 < argc) pk_file = argv[++i];
        else if (!strcmp(argv[i], "--kernel") && i+1 < argc) kernel_path = argv[++i];
        else if (!strcmp(argv[i], "--device") && i+1 < argc) device = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--work") && i+1 < argc) work = strtoull(argv[++i], NULL, 0);
        else if (!strcmp(argv[i], "--batch") && i+1 < argc) batch = strtoull(argv[++i], NULL, 0);
        else if (!strcmp(argv[i], "--poll") && i+1 < argc) poll_s = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--dry-run")) dry = 1;
        else if (!strcmp(argv[i], "--list-devices")) return list_devices();
        else if (!strcmp(argv[i], "--cpu-test")) {
            uint8_t h[32]; char hex[65];
            keccak256((const uint8_t*)"", 0, h);
            bin2hex(h, 32, hex);
            printf("empty keccak: 0x%s\n", hex);
            return strcmp(hex, "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470") ? 1 : 0;
        }
        else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
        else { fprintf(stderr, "unknown arg %s\n", argv[i]); usage(argv[0]); return 2; }
    }

    uint8_t sender[20], priv[32], contract_addr[20];
    int have_pk = 0;
    memset(priv, 0, 32);

    if (parse_addr(contract, contract_addr)) {
        fprintf(stderr, "bad --contract\n");
        return 2;
    }

    if (pk_file) {
        if (load_pk_file(pk_file, priv)) {
            fprintf(stderr, "cannot read pk file %s\n", pk_file);
            return 2;
        }
        have_pk = 1;
    } else if (pk_hex) {
        if (parse_priv(pk_hex, priv)) {
            fprintf(stderr, "bad --pk\n");
            return 2;
        }
        have_pk = 1;
    }

    if (sender_hex) {
        if (parse_addr(sender_hex, sender)) {
            fprintf(stderr, "bad --sender\n");
            return 2;
        }
        if (have_pk) {
            uint8_t derived[20];
            if (eth_priv_to_address(priv, derived) == 0 &&
                memcmp(derived, sender, 20) != 0) {
                fprintf(stderr, "warning: --sender does not match --pk address\n");
                print_hex32("  pk address: ", derived, 20); printf("\n");
            }
        }
    } else if (have_pk) {
        if (eth_priv_to_address(priv, sender)) {
            fprintf(stderr, "cannot derive address from key\n");
            return 2;
        }
    } else {
        fprintf(stderr, "--sender is required when no private key is given\n");
        return 2;
    }

    print_hex32("sender: ", sender, 20); printf("\n");
    printf("rpc: %s\ncontract: 0x", rpc_url);
    { char h[41]; bin2hex(contract_addr, 20, h); printf("%s\n", h); }
    printf("claim: %s\n", have_pk ? "enabled" : "disabled (mine-only)");

    rpc_t rpc;
    rpc_init(&rpc, rpc_url);

    prspct_state_t st;
    if (prspct_fetch_state(&rpc, contract, &st)) {
        fprintf(stderr, "failed to fetch state() — check RPC/contract\n");
        return 1;
    }

    print_hex32("seed:    ", st.seed, 32); printf("\n");
    print_hex32("target:  ", st.target, 32); printf("\n");
    printf("depth:   %" PRIu64 " / 8888\n", st.depth);

    if (st.depth >= 8888) {
        printf("vein is worked out — nothing to mine\n");
        return 0;
    }

    /* CPU cross-check of one hash vs base_state construction */
    {
        uint64_t lanes[17];
        uint8_t h1[32], h2[32];
        prspct_base_state(st.seed, sender, lanes);
        prspct_claim_hash(st.seed, sender, 0, h1);
        /* reconstruct from lanes with nonce 0: lane9 high already 0, lane10 = pad only */
        /* just ensure claim_hash is self-consistent */
        (void)lanes; (void)h2;
        char hex[65];
        bin2hex(h1, 32, hex);
        printf("sample hash(nonce=0): 0x%s\n", hex);
    }

    if (dry) {
        printf("dry-run ok\n");
        return 0;
    }

    ocl_ctx_t *gpu = ocl_create(device, kernel_path);
    if (!gpu) return 1;

    uint64_t total_hashes = 0;
    uint64_t t0 = now_ms();
    uint64_t last_depth = st.depth;

    while (!g_stop) {
        if (st.depth != last_depth) {
            print_hex32("job updated seed=", st.seed, 32);
            printf(" depth=%" PRIu64 "\n", st.depth);
            last_depth = st.depth;
        }

        uint64_t start = rand64();
        int found = 0;
        uint64_t fn = 0, hashed = 0;
        uint64_t lanes[17];
        prspct_base_state(st.seed, sender, lanes);
        if (ocl_search(gpu, lanes, st.target, start, work, batch, &found, &fn, &hashed) != 0) {
            fprintf(stderr, "ocl_search failed\n");
            break;
        }
        total_hashes += hashed;

        uint64_t elapsed = now_ms() - t0;
        uint64_t poll_ms = (uint64_t)poll_s * 1000;
        if (poll_ms < 2000) poll_ms = 2000;
        if (elapsed >= poll_ms) {
            double hs = (double)total_hashes * 1000.0 / (double)elapsed;
            printf("status: %.2f MH/s  hashes=%" PRIu64 "  depth=%" PRIu64 "\n",
                   hs / 1e6, total_hashes, st.depth);
            fflush(stdout);
            t0 = now_ms();
            total_hashes = 0;

            /* refresh state */
            prspct_state_t ns;
            if (prspct_fetch_state(&rpc, contract, &ns) == 0) {
                int same = ns.depth == st.depth && memcmp(ns.seed, st.seed, 32) == 0 &&
                           memcmp(ns.target, st.target, 32) == 0;
                st = ns;
                if (!same) {
                    printf("state changed (depth %" PRIu64 ")\n", st.depth);
                }
            }
        }

        if (!found) continue;

        /* verify on CPU */
        uint8_t h[32];
        prspct_claim_hash(st.seed, sender, fn, h);
        int under = 1;
        for (int i = 0; i < 32; i++) {
            if (h[i] < st.target[i]) break;
            if (h[i] > st.target[i]) { under = 0; break; }
        }
        char nhex[17], hhex[65];
        snprintf(nhex, sizeof(nhex), "%016" PRIx64, fn);
        bin2hex(h, 32, hhex);
        printf("FOUND nonce=0x%s\n  hash=0x%s\n  under=%d\n", nhex, hhex, under);
        fflush(stdout);
        if (!under) {
            printf("false positive (kernel mismatch) — skipping claim\n");
            continue;
        }

        if (!have_pk) {
            printf("no key: claim later with cast:\n");
            printf("  cast send %s 'claim(uint256)' %s --rpc-url %s --private-key $PK\n",
                   contract, nhex, rpc_url);
            printf("nonce=%s\n", nhex);
            /* keep mining next foot */
            continue;
        }

        /* refresh + claim */
        prspct_state_t ns;
        if (prspct_fetch_state(&rpc, contract, &ns) == 0) st = ns;

        uint64_t chain_id = DEFAULT_CHAIN, gas_price = 0, acct_nonce = 0;
        if (rpc_chain_id(&rpc, &chain_id) != 0) chain_id = DEFAULT_CHAIN;
        if (rpc_gas_price(&rpc, &gas_price) != 0) gas_price = 1000000000ULL; /* 1 gwei fallback */
        char sender_addr_hex[43];
        sender_addr_hex[0]='0'; sender_addr_hex[1]='x';
        bin2hex(sender, 20, sender_addr_hex + 2);
        if (rpc_get_nonce(&rpc, sender_addr_hex, &acct_nonce) != 0) {
            fprintf(stderr, "cannot get account nonce\n");
            continue;
        }

        char raw[4096];
        if (eth_build_claim_tx(priv, chain_id, acct_nonce, gas_price, DEFAULT_GAS,
                               contract_addr, fn, 0, 0, raw, sizeof(raw))) {
            fprintf(stderr, "failed to build claim tx\n");
            continue;
        }
        char txh[128];
        if (rpc_send_raw(&rpc, raw, txh, sizeof(txh)) != 0) {
            fprintf(stderr, "eth_sendRawTransaction failed (foot may be taken)\n");
            continue;
        }
        printf("CLAIMED tx=0x%s nonce=%s\n", txh, nhex);
        fflush(stdout);

        /* after claim, pull fresh state for next foot */
        sleep(2);
        if (prspct_fetch_state(&rpc, contract, &st) == 0) {
            printf("next depth %" PRIu64 "\n", st.depth);
        }
    }

    ocl_destroy(gpu);
    printf("stopped\n");
    return 0;
}
