#include "eth.h"
#include "keccak.h"
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/obj_mac.h>
#include <openssl/bn.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* secp256k1 order */
static const char *SECP_K1_ORDER =
    "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141";

int eth_priv_to_address(const uint8_t priv[32], uint8_t addr[20]) {
    EC_KEY *key = EC_KEY_new_by_curve_name(NID_secp256k1);
    if (!key) return -1;
    BIGNUM *bn = BN_bin2bn(priv, 32, NULL);
    if (!bn) { EC_KEY_free(key); return -1; }
    if (EC_KEY_set_private_key(key, bn) != 1) {
        BN_free(bn); EC_KEY_free(key); return -1;
    }
    const EC_GROUP *group = EC_KEY_get0_group(key);
    EC_POINT *pub = EC_POINT_new(group);
    if (!pub) { BN_free(bn); EC_KEY_free(key); return -1; }
    if (EC_POINT_mul(group, pub, bn, NULL, NULL, NULL) != 1) {
        EC_POINT_free(pub); BN_free(bn); EC_KEY_free(key); return -1;
    }
    EC_KEY_set_public_key(key, pub);

    /* uncompressed 65-byte pubkey */
    uint8_t pubbuf[65];
    size_t publen = EC_POINT_point2oct(group, pub, POINT_CONVERSION_UNCOMPRESSED,
                                       pubbuf, sizeof(pubbuf), NULL);
    if (publen != 65) {
        EC_POINT_free(pub); BN_free(bn); EC_KEY_free(key); return -1;
    }
    uint8_t hash[32];
    keccak256(pubbuf + 1, 64, hash);
    memcpy(addr, hash + 12, 20);

    EC_POINT_free(pub); BN_free(bn); EC_KEY_free(key);
    return 0;
}

/* RFC6979-ish: OpenSSL ECDSA_do_sign is non-deterministic; we try recid recovery.
 * Build the tx, sign digest, then recover v by checking both recoveries. */

static int rlp_append_addr(buf_t *b, const uint8_t addr[20]) {
    return rlp_bytes(b, addr, 20);
}

static int rlp_append_u256_from_u64pair(buf_t *b, uint64_t lo, uint64_t hi) {
    if (hi == 0) return rlp_u64(b, lo);
    uint8_t be[32];
    memset(be, 0, 32);
    for (int i = 0; i < 8; i++) {
        be[24 + i] = (uint8_t)(lo >> (56 - 8 * i));
        be[16 + i] = (uint8_t)(hi >> (56 - 8 * i));
    }
    /* trim leading zeros like rlp_u64 would */
    int start = 0;
    while (start < 32 && be[start] == 0) start++;
    return rlp_bytes(b, be + start, (size_t)(32 - start));
}

static int build_calldata(uint8_t out[36], uint64_t work_nonce) {
    /* claim(uint256) = 0x379607f5 */
    const uint8_t sel[4] = { 0x37, 0x96, 0x07, 0xf5 };
    memcpy(out, sel, 4);
    memset(out + 4, 0, 24);
    for (int i = 0; i < 8; i++)
        out[4 + 24 + i] = (uint8_t)(work_nonce >> (56 - 8 * i));
    return 0;
}

/* recover pubkey from sig; try recid 0/1 and match address */
static int recover_and_match(const uint8_t digest[32],
                             const uint8_t r[32], const uint8_t s[32],
                             int recid,
                             const uint8_t expect_addr[20],
                             int *matched) {
    *matched = 0;
    BIGNUM *R = BN_bin2bn(r, 32, NULL);
    BIGNUM *S = BN_bin2bn(s, 32, NULL);
    BIGNUM *e = BN_bin2bn(digest, 32, NULL);
    BIGNUM *order = NULL;
    BN_hex2bn(&order, SECP_K1_ORDER);
    if (!R || !S || !e || !order) goto fail;

    /* x = R (+ order if recid >= 2); we only need recid 0/1 */
    BIGNUM *x = BN_dup(R);
    BN_CTX *ctx = BN_CTX_new();
    BIGNUM *n = BN_new(); /* n = order */
    BN_copy(n, order);

    /* y^2 = x^3 + 7 mod p */
    BIGNUM *p = NULL;
    BN_hex2bn(&p, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F");
    BIGNUM *y2 = BN_new();
    BIGNUM *x3 = BN_new();
    BN_mod_sqr(y2, x, p, ctx);
    BN_mod_mul(y2, y2, x, p, ctx);          /* x^2 */
    BN_mod_add(x3, y2, BN_value_one(), p, ctx); /* not yet */
    /* redo cleanly: x3 = x^3 + 7 */
    BN_mod_mul(x3, x, x, p, ctx);
    BN_mod_mul(x3, x3, x, p, ctx);
    BIGNUM *seven = BN_new();
    BN_set_word(seven, 7);
    BN_mod_add(y2, x3, seven, p, ctx);

    /* sqrt mod p: y = y2^((p+1)/4) */
    BIGNUM *exp = BN_new();
    BN_copy(exp, p);
    BN_add_word(exp, 1);
    BN_rshift(exp, exp, 2);
    BIGNUM *y = BN_new();
    BN_mod_exp(y, y2, exp, p, ctx);

    /* pick y parity = recid & 1 */
    if ((BN_is_odd(y) ? 1 : 0) != (recid & 1))
        BN_sub(y, p, y);

    EC_GROUP *group = EC_GROUP_new_by_curve_name(NID_secp256k1);
    EC_POINT *Rpt = EC_POINT_new(group);
    BIGNUM *yp = BN_dup(y);
    if (!EC_POINT_set_affine_coordinates(group, Rpt, x, yp, ctx)) {
        /* older OpenSSL: set_Jprojective or set_affine_coordinates_GFp */
#ifdef EC_POINT_set_affine_coordinates_GFp
        EC_POINT_set_affine_coordinates_GFp(group, Rpt, x, yp, ctx);
#else
        goto fail_pt;
#endif
    }

    /* Q = r^{-1} (s*R - e*G)  ... standard ecrecover:
     * ecrecover: Q = r^{-1} (s*R - e*G)  for Ethereum
     * Actually: Q = r^{-1} * (s*R + (-e)*G) = r^{-1}(sR - eG)
     */
    BIGNUM *rinv = BN_mod_inverse(NULL, R, n, ctx);
    BIGNUM *neg_e = BN_new();
    BN_mod_sub(neg_e, n, e, n, ctx);

    EC_POINT *sR = EC_POINT_new(group);
    EC_POINT_mul(group, sR, NULL, Rpt, S, ctx); /* s * R */
    EC_POINT *eG = EC_POINT_new(group);
    EC_POINT_mul(group, eG, neg_e, NULL, NULL, ctx); /* (-e)*G */
    EC_POINT *sum = EC_POINT_new(group);
    EC_POINT_add(group, sum, sR, eG, ctx);
    EC_POINT *Q = EC_POINT_new(group);
    EC_POINT_mul(group, Q, NULL, sum, rinv, ctx);

    uint8_t pubbuf[65];
    size_t publen = EC_POINT_point2oct(group, Q, POINT_CONVERSION_UNCOMPRESSED,
                                       pubbuf, sizeof(pubbuf), ctx);
    if (publen == 65) {
        uint8_t hash[32], addr[20];
        keccak256(pubbuf + 1, 64, hash);
        memcpy(addr, hash + 12, 20);
        if (memcmp(addr, expect_addr, 20) == 0) *matched = 1;
    }

    EC_POINT_free(Q); EC_POINT_free(sum); EC_POINT_free(eG); EC_POINT_free(sR);
    EC_POINT_free(Rpt); BN_free(yp); EC_GROUP_free(group);
    BN_free(exp); BN_free(y); BN_free(seven); BN_free(y2); BN_free(x3);
    BN_free(p); BN_free(n); BN_free(x); BN_CTX_free(ctx);
    BN_free(R); BN_free(S); BN_free(e); BN_free(order);
    return 0;

fail_pt:
    EC_POINT_free(Rpt); BN_free(yp); EC_GROUP_free(group);
    BN_free(exp); BN_free(y); BN_free(seven); BN_free(y2); BN_free(x3);
    BN_free(p); BN_free(n); BN_free(x); BN_CTX_free(ctx);
fail:
    if (R) BN_free(R);
    if (S) BN_free(S);
    if (e) BN_free(e);
    if (order) BN_free(order);
    return -1;
}

int eth_build_claim_tx(
    const uint8_t priv[32],
    uint64_t chain_id,
    uint64_t account_nonce,
    uint64_t gas_price,
    uint64_t gas_limit,
    const uint8_t contract[20],
    uint64_t work_nonce,
    uint64_t value_wei_lo,
    uint64_t value_wei_hi,
    char *raw0x, size_t raw_cap
) {
    uint8_t addr[20];
    if (eth_priv_to_address(priv, addr)) return -1;

    uint8_t calldata[36];
    build_calldata(calldata, work_nonce);

    /* unsigned payload items (already RLP) */
    buf_t items;
    buf_init(&items);
    if (rlp_u64(&items, account_nonce)) goto err;
    if (rlp_u64(&items, gas_price)) goto err;
    if (rlp_u64(&items, gas_limit)) goto err;
    if (rlp_append_addr(&items, contract)) goto err;
    if (rlp_append_u256_from_u64pair(&items, value_wei_lo, value_wei_hi)) goto err;
    if (rlp_bytes(&items, calldata, 36)) goto err;
    if (rlp_u64(&items, chain_id)) goto err;
    if (rlp_u64(&items, 0)) goto err;
    if (rlp_u64(&items, 0)) goto err;

    buf_t unsigned_list;
    buf_init(&unsigned_list);
    if (rlp_list(&unsigned_list, items.data, items.len)) goto err2;

    uint8_t digest[32];
    keccak256(unsigned_list.data, unsigned_list.len, digest);

    EC_KEY *key = EC_KEY_new_by_curve_name(NID_secp256k1);
    BIGNUM *bn = BN_bin2bn(priv, 32, NULL);
    if (!key || !bn) goto err3;
    EC_KEY_set_private_key(key, bn);
    const EC_GROUP *group = EC_KEY_get0_group(key);
    EC_POINT *pub = EC_POINT_new(group);
    EC_POINT_mul(group, pub, bn, NULL, NULL, NULL);
    EC_KEY_set_public_key(key, pub);

    ECDSA_SIG *sig = ECDSA_do_sign(digest, 32, key);
    if (!sig) goto err4;

    const BIGNUM *br = NULL, *bs = NULL;
    ECDSA_SIG_get0(sig, &br, &bs);
    uint8_t r[32], s[32];
    memset(r, 0, 32); memset(s, 0, 32);
    BN_bn2binpad(br, r, 32);
    BN_bn2binpad(bs, s, 32);

    /* low-s (EIP-2) */
    BIGNUM *half = NULL;
    BN_hex2bn(&half, "7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0");
    if (BN_cmp(bs, half) > 0) {
        BIGNUM *order = NULL;
        BN_hex2bn(&order, SECP_K1_ORDER);
        BIGNUM *s2 = BN_new();
        BN_sub(s2, order, bs);
        BN_bn2binpad(s2, s, 32);
        ECDSA_SIG_set0(sig, BN_dup(br), s2); /* takes ownership of s2 */
        BN_free(order);
    }
    BN_free(half);

    int v = -1;
    for (int recid = 0; recid < 2; recid++) {
        int m = 0;
        if (recover_and_match(digest, r, s, recid, addr, &m) == 0 && m) {
            v = recid;
            break;
        }
    }
    if (v < 0) goto err5;

    uint64_t v_eth = chain_id * 2 + 35 + (uint64_t)v;

    /* signed list */
    buf_t sitems;
    buf_init(&sitems);
    if (rlp_u64(&sitems, account_nonce)) goto err7;
    if (rlp_u64(&sitems, gas_price)) goto err7;
    if (rlp_u64(&sitems, gas_limit)) goto err7;
    if (rlp_append_addr(&sitems, contract)) goto err7;
    if (rlp_append_u256_from_u64pair(&sitems, value_wei_lo, value_wei_hi)) goto err7;
    if (rlp_bytes(&sitems, calldata, 36)) goto err7;
    if (rlp_u64(&sitems, v_eth)) goto err7;
    if (rlp_bytes(&sitems, r, 32)) goto err7;
    if (rlp_bytes(&sitems, s, 32)) goto err7;

    buf_t signed_list;
    buf_init(&signed_list);
    if (rlp_list(&signed_list, sitems.data, sitems.len)) goto err7;

    if (raw_cap < signed_list.len * 2 + 3) goto err8;
    raw0x[0] = '0'; raw0x[1] = 'x';
    bin2hex(signed_list.data, signed_list.len, raw0x + 2);

    buf_free(&signed_list); buf_free(&sitems);
    ECDSA_SIG_free(sig); EC_POINT_free(pub); BN_free(bn); EC_KEY_free(key);
    buf_free(&unsigned_list); buf_free(&items);
    return 0;

err8: buf_free(&signed_list);
err7: buf_free(&sitems);
err5: ECDSA_SIG_free(sig);
err4: EC_POINT_free(pub); BN_free(bn); EC_KEY_free(key);
err3: if (key) EC_KEY_free(key); if (bn) BN_free(bn);
err2: buf_free(&unsigned_list);
err:  buf_free(&items);
    return -1;
}
