#!/usr/bin/env bash
# Install prspct OpenCL miner into HiveOS custom miner dir.
# Run ON THE RIG as root:  sudo ./install-hiveos.sh
set -euo pipefail

DEST="${1:-/hive/miners/custom/prspct}"
SRC="$(cd "$(dirname "$0")" && pwd)"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "This installer is for HiveOS (Linux). Build on the rig or cross-build Linux." >&2
  echo "On the rig: install OpenCL (rocm-opencl / amdgpu-pro) then make && $0" >&2
  exit 1
fi

if [[ ! -x "$SRC/prspct-miner" ]]; then
  echo "Build first:  make" >&2
  exit 1
fi

mkdir -p "$DEST"
install -m 755 "$SRC/prspct-miner" "$DEST/prspct-miner"
install -m 644 "$SRC/src/kernel.cl" "$DEST/kernel.cl"
install -m 755 "$SRC/hive/h-run.sh" "$DEST/h-run.sh"
install -m 755 "$SRC/hive/h-stats.sh" "$DEST/h-stats.sh"
install -m 755 "$SRC/hive/h-config.sh" "$DEST/h-config.sh"
install -m 644 "$SRC/hive/h-manifest.conf" "$DEST/h-manifest.conf"

if [[ ! -f "$DEST/pk.txt" ]]; then
  cat > "$DEST/pk.txt.example" <<'EOF'
# put your 32-byte private key hex here (with or without 0x), then:
#   mv pk.txt.example pk.txt && chmod 600 pk.txt
0xYOUR_PRIVATE_KEY_HERE
EOF
  echo "Wrote $DEST/pk.txt.example — copy to pk.txt and chmod 600"
fi

echo "Installed to $DEST"
echo "1) chmod 600 $DEST/pk.txt  (after adding your key)"
echo "2) Flight sheet: Installation URL = this package, or Custom miner"
echo "3) Wallet: your ETH address on Robinhood Chain; Pool URL can be the RPC"
echo "4) Start miner, watch: tail -f /var/log/miner/prspct.log"
