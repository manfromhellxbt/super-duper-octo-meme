#!/usr/bin/env bash
# HiveOS custom miner launcher for PRSPCT (Robinhood Chain 4663)
set -euo pipefail
cd "$(dirname "$0")"

export PRSPCT_KERNEL_PATH="${PRSPCT_KERNEL_PATH:-$PWD/kernel.cl}"
PK_FILE="${PRSPCT_PK_FILE:-$PWD/pk.txt}"
RPC="${PRSPCT_RPC:-https://rpc.mainnet.chain.robinhood.com}"
CONTRACT="${PRSPCT_CONTRACT:-0xd078008c3D887A52CE722A3cA0539cA1F4971dD1}"
DEVICE="${PRSPCT_DEVICE:-0}"
WORK="${PRSPCT_WORK:-262144}"
BATCH="${PRSPCT_BATCH:-256}"
POLL="${PRSPCT_POLL:-8}"

ARGS=(--rpc "$RPC" --contract "$CONTRACT" --device "$DEVICE" --work "$WORK" --batch "$BATCH" --poll "$POLL")

if [[ -f "$PK_FILE" ]]; then
  ARGS+=(--pk-file "$PK_FILE")
elif [[ -n "${PRSPCT_PK:-}" ]]; then
  ARGS+=(--pk "$PRSPCT_PK")
elif [[ -n "${PRSPCT_SENDER:-}" ]]; then
  ARGS+=(--sender "$PRSPCT_SENDER")
else
  echo "prspct: set pk.txt, PRSPCT_PK, or PRSPCT_SENDER" >&2
  exit 1
fi

# optional extra args from flight sheet custom user config
# shellcheck disable=SC2206
EXTRA=(${PRSPCT_EXTRA:-})

exec ./prspct-miner "${ARGS[@]}" "${EXTRA[@]}"
