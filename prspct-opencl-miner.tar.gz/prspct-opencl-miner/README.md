# prspct OpenCL miner (HiveOS)

Custom GPU miner for **PRSPCT Consolidated Mining and Dividend Company** on
**Robinhood Chain (4663)**.

Contract: `0xd078008c3D887A52CE722A3cA0539cA1F4971dD1`

Hash: `keccak256(seed ‖ sender ‖ nonce_u256be) < target`  
Claim: `claim(nonce) payable` with `value = 0` (full sweat)

This is **not** Ethash/KawPow. It is a custom single-block Keccak PoW.
The official site mines in the browser; this package mines on an OpenCL GPU
and submits the claim transaction itself.

> The prospectus states the till is a pyramid paid only from later coin
> buyers. Use at your own risk. Nothing here is financial advice.

## Build (on the HiveOS rig)

```bash
# deps: gcc, make, libcurl, OpenSSL, OpenCL (ROCm or amdgpu-pro)
sudo apt-get install -y build-essential libcurl4-openssl-dev libssl-dev ocl-icd-opencl-dev

git clone <this-folder> && cd prspct-opencl-miner
make
make test-keccak
```

## Install into HiveOS

```bash
sudo ./install-hiveos.sh
# → /hive/miners/custom/prspct/

cd /hive/miners/custom/prspct
cp pk.txt.example pk.txt   # or create pk.txt
chmod 600 pk.txt           # paste 32-byte private key hex
```

## Run

```bash
./h-run.sh
# or directly:
./prspct-miner --pk-file pk.txt --device 0
```

Useful flags:

| Flag | Meaning |
|------|---------|
| `--list-devices` | show OpenCL GPUs |
| `--dry-run` | fetch `state()`, print job, exit (no GPU) |
| `--cpu-test` | keccak self-test |
| `--device N` | GPU index |
| `--work N` | work-items per launch (default 262144) |
| `--batch N` | hashes per work-item (default 256) |
| `--poll N` | seconds between `state()` refresh (default 8) |
| `--sender 0x..` | mine without a key (no auto-claim) |

## HiveOS flight sheet

- Miner: **Custom**
- Installation URL: path/URL of this package (or install manually as above)
- Wallet: your address (used only for display; the miner derives address from `pk.txt`)
- Pool URL / host: `https://rpc.mainnet.chain.robinhood.com` (optional override via `PRSPCT_RPC`)
- Extra env (optional): `PRSPCT_DEVICE`, `PRSPCT_WORK`, `PRSPCT_BATCH`, `PRSPCT_POLL`

## Layout

```
prspct-opencl-miner/
  Makefile
  install-hiveos.sh
  src/
    kernel.cl      OpenCL Keccak search
    main.c         job loop + claim
    opencl_host.c  GPU host
    keccak.c/h     CPU hash + base state
    eth.c/h        EIP-155 claim tx (OpenSSL secp256k1)
    rpc.c/h        JSON-RPC
    util.c/h       hex / RLP / buffers
    sha3.c/h       keccak-f1600
  hive/
    h-run.sh h-stats.sh h-config.sh h-manifest.conf
```

## Security

- Put the private key only in `pk.txt` with mode `600` on the rig.
- Prefer a **hot wallet** with just enough ETH for gas, not a cold wallet.
- Anyone with that key can spend the wallet’s funds.

## What it does on a hit

1. GPU finds `nonce` under the current `target`
2. CPU re-verifies the hash
3. Builds EIP-155 legacy `claim(nonce)` tx (`value=0`)
4. `eth_sendRawTransaction`
5. Refreshes `state()` and continues to the next foot
