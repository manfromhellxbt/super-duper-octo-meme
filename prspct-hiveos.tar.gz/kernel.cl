// PRSPCT claim hash: keccak256(seed || sender || nonce_u256be) < target
// One 136-byte Keccak block. Seed+sender constant per job; nonce is uint256 BE
// with only the low 64 bits set (enough: expected work is ~2^31 at depth ~2300).

__constant ulong RC[24] = {
    0x0000000000000001UL, 0x0000000000008082UL, 0x800000000000808aUL, 0x8000000080008000UL,
    0x000000000000808bUL, 0x0000000080000001UL, 0x8000000080008081UL, 0x8000000000008009UL,
    0x000000000000008aUL, 0x0000000000000088UL, 0x0000000080008009UL, 0x000000008000000aUL,
    0x000000008000808bUL, 0x800000000000008bUL, 0x8000000000008089UL, 0x8000000000008003UL,
    0x8000000000008002UL, 0x8000000000000080UL, 0x000000000000800aUL, 0x800000000000000aUL,
    0x8000000080008081UL, 0x8000000000008080UL, 0x0000000080000001UL, 0x8000000080008008UL
};

inline ulong rotl64(ulong x, int n) { return (x << n) | (x >> (64 - n)); }

inline uint bswap32(uint x) {
    return (x << 24) | ((x & 0x0000ff00u) << 8) | ((x & 0x00ff0000u) >> 8) | (x >> 24);
}

inline void keccakf(ulong s[25]) {
    ulong bc[5], t;
    const int RHO[24] = {
        1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14,
        27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44
    };
    const int PI[24] = {
        10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4,
        15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1
    };

    for (int round = 0; round < 24; round++) {
        for (int i = 0; i < 5; i++)
            bc[i] = s[i] ^ s[i + 5] ^ s[i + 10] ^ s[i + 15] ^ s[i + 20];
        for (int i = 0; i < 5; i++) {
            t = bc[(i + 4) % 5] ^ rotl64(bc[(i + 1) % 5], 1);
            for (int j = 0; j < 25; j += 5) s[j + i] ^= t;
        }

        t = s[1];
        for (int i = 0; i < 24; i++) {
            int j = PI[i];
            bc[0] = s[j];
            s[j] = rotl64(t, RHO[i]);
            t = bc[0];
        }

        for (int j = 0; j < 25; j += 5) {
            ulong a0 = s[j], a1 = s[j + 1], a2 = s[j + 2], a3 = s[j + 3], a4 = s[j + 4];
            s[j + 0] = a0 ^ ((~a1) & a2);
            s[j + 1] = a1 ^ ((~a2) & a3);
            s[j + 2] = a2 ^ ((~a3) & a4);
            s[j + 3] = a3 ^ ((~a4) & a0);
            s[j + 4] = a4 ^ ((~a0) & a1);
        }

        s[0] ^= RC[round];
    }
}

/*
 * Padded 136-byte block:
 *   [0,32)  seed
 *   [32,52) sender
 *   [52,84) nonce uint256 BE  (only low 64 bits nonzero -> lives in [76,84))
 *   [84]    0x01
 *   [135]   0x80
 *
 * Lane i = bytes [8i, 8i+8) little-endian.
 * Constant lanes: 0..8, 11..16 (lane 16 holds 0x80 at its MSB).
 * Lane 9  (bytes 72-79): 4 zero + 4 BE bytes of (nonce >> 32)
 * Lane 10 (bytes 80-87): 4 BE bytes of nonce low + 0x01 pad + 3 zero
 */
__kernel void prspct_search(
    __global const ulong *base_state, // 17 lanes, nonce slots already 0, pad applied
    __global const uchar  *target32,
    const ulong start_nonce,
    const ulong stride,
    const ulong hashes_per_item,
    volatile __global int *found,
    __global ulong *found_nonce,
    __global ulong *hash_count
) {
    size_t gid = get_global_id(0);
    ulong nonce = start_nonce + (ulong)gid * stride;

    ulong c0 = base_state[0],  c1 = base_state[1],  c2 = base_state[2],  c3 = base_state[3];
    ulong c4 = base_state[4],  c5 = base_state[5],  c6 = base_state[6],  c7 = base_state[7];
    ulong c8 = base_state[8];
    ulong c11 = base_state[11], c12 = base_state[12], c13 = base_state[13];
    ulong c14 = base_state[14], c15 = base_state[15], c16 = base_state[16];

    ulong local_count = 0;

    for (ulong k = 0; k < hashes_per_item; k++) {
        if (found[0]) break;

        ulong s[25];
        s[0] = c0; s[1] = c1; s[2] = c2; s[3] = c3; s[4] = c4;
        s[5] = c5; s[6] = c6; s[7] = c7; s[8] = c8;
        s[9]  = ((ulong)bswap32((uint)(nonce >> 32)) << 32);
        s[10] = (ulong)bswap32((uint)nonce) | (1UL << 32);
        s[11] = c11; s[12] = c12; s[13] = c13; s[14] = c14; s[15] = c15; s[16] = c16;
        s[17] = s[18] = s[19] = s[20] = s[21] = s[22] = s[23] = s[24] = 0UL;

        keccakf(s);

        // LE dump of lanes 0..3 is the digest; compare as big-endian integer
        uchar h0 = (uchar)(s[0] & 0xff);
        int cmp = -1;
        if (h0 > target32[0]) cmp = 1;
        else if (h0 == target32[0]) {
            cmp = 0;
            for (int bi = 1; bi < 32; bi++) {
                uchar hb = (uchar)((s[bi >> 3] >> (8 * (bi & 7))) & 0xff);
                if (hb < target32[bi]) { cmp = -1; break; }
                if (hb > target32[bi]) { cmp = 1; break; }
            }
        }

        local_count++;

        if (cmp < 0) {
            if (atomic_cmpxchg(found, 0, 1) == 0)
                found_nonce[0] = nonce;
            break;
        }

        nonce += stride;
    }

    hash_count[gid] = local_count;
}
