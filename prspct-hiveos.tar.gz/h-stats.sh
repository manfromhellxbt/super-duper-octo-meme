#!/usr/bin/env bash
# HiveOS stats — sum hashrate across all prspct GPU logs (awk only)
cd "$(dirname "$0")" 2>/dev/null || true

HS=0
for LOG in /tmp/prspct-gpu*.log /tmp/prspct.log /tmp/p0.log /tmp/p1.log \
           /var/log/miner/custom.log /var/log/miner/prspct.log; do
  [[ -f "$LOG" ]] || continue
  last=$(grep -oE 'status: [0-9.]+ MH/s' "$LOG" 2>/dev/null | tail -1 | awk '{print $2}')
  [[ -n "$last" ]] || continue
  HS=$(awk -v a="$HS" -v b="$last" 'BEGIN{printf "%.2f", a+b}')
done

if [[ "$HS" == "0" ]] && pgrep -f 'prspct-miner' >/dev/null 2>&1; then
  HS=1
fi

TEMP=0
FAN=0
if command -v nvidia-smi >/dev/null 2>&1; then
  TEMP=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
  FAN=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
fi
[[ "$TEMP" =~ ^[0-9]+$ ]] || TEMP=0
[[ "$FAN" =~ ^[0-9]+$ ]] || FAN=0

UPTIME=0
if pgrep -f 'prspct-miner' >/dev/null 2>&1; then
  UPTIME=$(ps -o etimes= -C prspct-miner 2>/dev/null | head -1 | tr -d ' ')
  [[ "$UPTIME" =~ ^[0-9]+$ ]] || UPTIME=0
fi

echo "{\"hs\":[$HS],\"hs_units\":\"mhs\",\"temp\":[$TEMP],\"fan\":[$FAN],\"uptime\":$UPTIME}"
exit 0
