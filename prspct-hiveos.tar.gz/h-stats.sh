#!/usr/bin/env bash
# HiveOS stats — must always print JSON and exit 0
cd "$(dirname "$0")" 2>/dev/null || true

# find the newest miner log
LOG=""
for c in "$1" /tmp/prspct.log /var/log/miner/custom.log /var/log/miner/prspct.log \
         /var/log/miner/custom/custom.log; do
  [[ -n "$c" && -f "$c" ]] || continue
  LOG="$c"
  break
done
if [[ -z "$LOG" ]]; then
  LOG=$(ls -t /tmp/prspct*.log /var/log/miner/*.log 2>/dev/null | head -1 || true)
fi

HS=0
if [[ -n "${LOG:-}" && -f "$LOG" ]]; then
  # "status: 865.38 MH/s"
  HS=$(grep -oE 'status: [0-9.]+ MH/s' "$LOG" 2>/dev/null | tail -1 | awk '{print $2}' || true)
  [[ -n "$HS" ]] || HS=0
fi

# if process is alive but log lagging, report a small non-zero so Hive doesn't restart
if [[ "$HS" == "0" ]] && pgrep -f 'prspct-miner' >/dev/null 2>&1; then
  HS=1
fi

TEMP=0
FAN=0
if command -v nvidia-smi >/dev/null 2>&1; then
  TEMP=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
  FAN=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
fi
[[ "$TEMP" =~ ^[0-9]+$ ]] || TEMP=0
[[ "$FAN" =~ ^[0-9]+$ ]] || FAN=0

UPTIME=0
if pgrep -f 'prspct-miner' >/dev/null 2>&1; then
  UPTIME=$(ps -o etimes= -C prspct-miner 2>/dev/null | head -1 | tr -d ' ' || true)
  [[ "$UPTIME" =~ ^[0-9]+$ ]] || UPTIME=0
fi

echo "{\"hs\":[$HS],\"hs_units\":\"mhs\",\"temp\":[$TEMP],\"fan\":[$FAN],\"uptime\":$UPTIME}"
exit 0
