#!/usr/bin/env bash
# HiveOS custom miner: PRSPCT (Robinhood Chain 4663)
# Starts one prspct-miner per OpenCL/NVIDIA GPU.
set -uo pipefail
cd "$(dirname "$0")"

chmod +x ./prspct-miner 2>/dev/null || true
export PRSPCT_KERNEL_PATH="${PRSPCT_KERNEL_PATH:-$PWD/kernel.cl}"

RPC="${PRSPCT_RPC:-https://rpc.mainnet.chain.robinhood.com}"
CONTRACT="${PRSPCT_CONTRACT:-0xd078008c3D887A52CE722A3cA0539cA1F4971dD1}"
WORK="${PRSPCT_WORK:-131072}"
BATCH="${PRSPCT_BATCH:-64}"
POLL="${PRSPCT_POLL:-8}"

if [[ -f ./config.env ]]; then
  # shellcheck disable=SC1091
  source ./config.env
fi

PK=""
for p in ./pk.txt ./prspct/pk.txt /hive/miners/custom/pk.txt /hive/miners/custom/prspct/pk.txt; do
  if [[ -f "$p" ]]; then PK="$p"; break; fi
done

if [[ -n "$PK" ]]; then
  :
elif [[ -n "${PRSPCT_PK:-}" ]]; then
  PK=""
elif [[ -n "${PRSPCT_SENDER:-}" ]]; then
  PK=""
else
  echo "prspct: no key found (pk.txt)"
  exit 1
fi

# Detect GPU indices
DEVICES=()
if [[ -n "${PRSPCT_DEVICE:-}" ]]; then
  # explicit override: "0" or "0,1"
  IFS=',' read -ra DEVICES <<< "$PRSPCT_DEVICE"
elif command -v nvidia-smi >/dev/null 2>&1; then
  while IFS= read -r idx; do
    [[ -n "$idx" ]] && DEVICES+=("$idx")
  done < <(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | tr -d ' ')
fi

if [[ ${#DEVICES[@]} -eq 0 ]]; then
  DEVICES=(0)
fi

echo "prspct: devices=${DEVICES[*]} work=$WORK batch=$BATCH key=${PK:-env}"

# Kill leftover instances
pkill -9 -f './prspct-miner' 2>/dev/null || true
sleep 1

# Launch one process per GPU; parent stays alive as supervisor
pids=()
for d in "${DEVICES[@]}"; do
  d=$(echo "$d" | tr -d '[:space:]')
  [[ -n "$d" ]] || continue
  args=(--rpc "$RPC" --contract "$CONTRACT" --device "$d" --work "$WORK" --batch "$BATCH" --poll "$POLL")
  if [[ -n "$PK" ]]; then
    args+=(--pk-file "$PK")
  elif [[ -n "${PRSPCT_PK:-}" ]]; then
    args+=(--pk "$PRSPCT_PK")
  else
    args+=(--sender "$PRSPCT_SENDER")
  fi
  echo "prspct: start device=$d"
  ./prspct-miner "${args[@]}" >> "/tmp/prspct-gpu${d}.log" 2>&1 &
  pids+=($!)
done

if [[ ${#pids[@]} -eq 0 ]]; then
  echo "prspct: nothing started"
  exit 1
fi

# Keep HiveOS happy: wait on any child; if one dies, kill rest and exit
wait -n "${pids[@]}" 2>/dev/null || wait "${pids[0]}"
code=$?
echo "prspct: a worker exited code=$code, stopping the rest"
kill "${pids[@]}" 2>/dev/null || true
wait 2>/dev/null || true
exit "$code"
