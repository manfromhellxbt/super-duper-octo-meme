#!/usr/bin/env bash
# HiveOS custom miner: PRSPCT (Robinhood Chain 4663)
set -uo pipefail
cd "$(dirname "$0")"

chmod +x ./prspct-miner 2>/dev/null || true
export PRSPCT_KERNEL_PATH="${PRSPCT_KERNEL_PATH:-$PWD/kernel.cl}"

RPC="${PRSPCT_RPC:-https://rpc.mainnet.chain.robinhood.com}"
CONTRACT="${PRSPCT_CONTRACT:-0xd078008c3D887A52CE722A3cA0539cA1F4971dD1}"
DEVICE="${PRSPCT_DEVICE:-0}"
WORK="${PRSPCT_WORK:-131072}"
BATCH="${PRSPCT_BATCH:-64}"
POLL="${PRSPCT_POLL:-8}"

if [[ -f ./config.env ]]; then
  # shellcheck disable=SC1091
  source ./config.env
fi

# find key: ./pk.txt, parent, or env
PK=""
for p in ./pk.txt ./prspct/pk.txt /hive/miners/custom/pk.txt /hive/miners/custom/prspct/pk.txt; do
  if [[ -f "$p" ]]; then PK="$p"; break; fi
done

ARGS=(--rpc "$RPC" --contract "$CONTRACT" --device "$DEVICE" --work "$WORK" --batch "$BATCH" --poll "$POLL")

if [[ -n "$PK" ]]; then
  ARGS+=(--pk-file "$PK")
elif [[ -n "${PRSPCT_PK:-}" ]]; then
  ARGS+=(--pk "$PRSPCT_PK")
elif [[ -n "${PRSPCT_SENDER:-}" ]]; then
  ARGS+=(--sender "$PRSPCT_SENDER")
else
  echo "prspct: no key found (pk.txt)"
  # still exit non-zero so Hive shows an error, not a silent 0
  exit 1
fi

echo "prspct: starting $(date -u +%H:%M:%S) device=$DEVICE work=$WORK batch=$BATCH key=$PK"
# HiveOS extra args from flight sheet (optional)
# shellcheck disable=SC2086
exec ./prspct-miner "${ARGS[@]}" ${CUSTOM_USER_CONFIG:-}
