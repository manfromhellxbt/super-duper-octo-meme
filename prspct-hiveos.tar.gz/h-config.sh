#!/usr/bin/env bash
# Optional HiveOS config hook — leave defaults; override via env in flight sheet.
set -euo pipefail
exit 0
